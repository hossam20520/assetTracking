<?php
namespace App\Http\Controllers;

use App\Models\Item;
use App\Models\Category;

use App\utils\helpers;
use Carbon\Carbon;
use DB;
use Illuminate\Http\Request;
use Intervention\Image\ImageManagerStatic as Image;

class ItemsController extends Controller
{

    //------------ GET ALL Items -----------\

    public function index(Request $request)
    {
        // $this->authorizeForUser($request->user('api'), 'view', Item::class);
        // How many items do you want to display.
        $perPage = $request->limit;
        $pageStart = \Request::get('page', 1);
        // Start displaying items from this number;
        $offSet = ($pageStart * $perPage) - $perPage;
        $order = $request->SortField;
        $dir = $request->SortType;
        $helpers = new helpers();
        $id = $request->id;

        $items = Item::where('deleted_at', '=', null)->where('room_id' , $id)->where(function ($query) use ($request) {
                return $query->when($request->filled('search'), function ($query) use ($request) {
                    return $query->where('ar_name', 'LIKE', "%{$request->search}%")
                        ->orWhere('en_name', 'LIKE', "%{$request->search}%");
                });
            });
        $totalRows = $items->count();
        $items = $items->offset($offSet)
            ->limit($perPage)
            ->orderBy($order, $dir)
            ->get();


            $categories = Category::where('deleted_at', null)->get(['id', 'name']);
 
            
            
     

        return response()->json([
            'items' => $items,
            'totalRows' => $totalRows,
            'categories' => $categories,
        ]);

    }


        // import Products
        public function import_items(Request $request)
        {
            try {
                \DB::transaction(function () use ($request) {
                    $file_upload = $request->file('items');
                    $ext = pathinfo($file_upload->getClientOriginalName(), PATHINFO_EXTENSION);
                    if ($ext != 'csv') {
                        return response()->json([
                            'msg' => 'must be in csv format',
                            'status' => false,
                        ]);
                    } else {
                        $data = array();
                        $rowcount = 0;
                        if (($handle = fopen($file_upload, "r")) !== false) {
    
                            $max_line_length = defined('MAX_LINE_LENGTH') ? MAX_LINE_LENGTH : 10000;
                            $header = fgetcsv($handle, $max_line_length);
                            $header_colcount = count($header);
                            while (($row = fgetcsv($handle, $max_line_length)) !== false) {
                                $row_colcount = count($row);
                                if ($row_colcount == $header_colcount) {
                                    $entry = array_combine($header, $row);
                                    $data[] = $entry;
                                } else {
                                    return null;
                                }
                                $rowcount++;
                            }
                            fclose($handle);
                        } else {
                            return null;
                        }
    
    
                        // $warehouses = Warehouse::where('deleted_at', null)->pluck('id')->toArray();
    
                        //-- Create New Product
                        foreach ($data as $key => $value) {


                            $category = Item::firstOrCreate([
                                'room_id'=> $value['room_id'],
                                'ar_name' => $value['items']  ,
                               'category_id'=> $value['category_id'] ,
                               'status'=> $value['status'] ,
                               'purchase_date'=> $value['purchase_date'] ,
                            
                            ]);
                            // $category_id = $category->id;
    
                            // $unit = Unit::where(['ShortName' => $value['unit']])
                            //     ->orWhere(['name' => $value['unit']])->first();
                            // $unit_id = $unit->id;
    
                            // if ($value['brand'] != 'N/A' && $value['brand'] != '') {
                            //     $brand = Brand::firstOrCreate(['name' => $value['brand']]);
                            //     $brand_id = $brand->id;
                            // } else {
                            //     $brand_id = null;
                            // }


                            // $Product = new Product;
                            // $Product->name = $value['name'] == '' ? null : $value['name'];
                            // $Product->code = $value['code'] == '' ? '11111111' : $value['code'];
                            // $Product->Type_barcode = 'CODE128';
                            // $Product->price = $value['price'];
                            // $Product->cost = $value['cost'];
                            // $Product->category_id = $category_id;
                            // $Product->brand_id = $brand_id;
                            // $Product->TaxNet = 0;
                            // $Product->tax_method = 1;
                            // $Product->note = $value['note'] ? $value['note'] : '';
                            // $Product->unit_id = $unit_id;
                            // $Product->unit_sale_id = $unit_id;
                            // $Product->unit_purchase_id = $unit_id;
                            // $Product->stock_alert = $value['stock_alert'] ? $value['stock_alert'] : 0;
                            // $Product->is_variant = 0;
                            // $Product->image = 'no-image.png';
                            // $Product->save();
    
                            // if ($warehouses) {
                            //     foreach ($warehouses as $warehouse) {
                            //         $product_warehouse[] = [
                            //             'product_id' => $Product->id,
                            //             'warehouse_id' => $warehouse,
                            //         ];
                            //     }
                            // }
                        }



                        // if ($warehouses) {
                        //     product_warehouse::insert($product_warehouse);
                        // }
                    }
                }, 10);
                return response()->json([
                    'status' => true,
                ], 200);
    
            } catch (ValidationException $e) {
                return response()->json([
                    'status' => false,
                    'msg' => 'error',
                    'errors' => $e->errors(),
                ]);
            }
    
        }

    //---------------- STORE NEW Item -------------\

    public function store(Request $request)
    {
        // $this->authorizeForUser($request->user('api'), 'create', Item::class);

        request()->validate([
            'ar_name' => 'required',
        ]);

        \DB::transaction(function () use ($request) {

            if ($request->hasFile('image')) {

                $image = $request->file('image');
                $filename = rand(11111111, 99999999) . $image->getClientOriginalName();

                $image_resize = Image::make($image->getRealPath());
                // $image_resize->resize(200, 200);
                $image_resize->save(public_path('/images/items/' . $filename));

            } else {
                $filename = 'no-image.png';
            }

            $Item = new Item;
            $Item->ar_name = $request['ar_name'];
            $Item->room_id = $request['room_id'];
            $Item->status = $request['status'];
            $Item->category_id = $request['category_id'];
            $Item->purchase_date = $request['purchase_date'];
            $Item->image = $filename;
            $Item->save();

        }, 10);

        return response()->json(['success' => true]);

    }

     //------------ function show -----------\

     public function show($id){
        //
    
    }

     //---------------- UPDATE Item -------------\

     public function update(Request $request, $id)
     {
 
        //  $this->authorizeForUser($request->user('api'), 'update', Item::class);
 
         request()->validate([
             'ar_name' => 'required',
         ]);
         \DB::transaction(function () use ($request, $id) {
             $Item = Item::findOrFail($id);
             $currentImage = $Item->image;
 
             // dd($request->image);
             if ($currentImage && $request->image != $currentImage) {
                 $image = $request->file('image');
                 $path = public_path() . '/images/items';
                 $filename = rand(11111111, 99999999) . $image->getClientOriginalName();
 
                 $image_resize = Image::make($image->getRealPath());
                //  $image_resize->resize(200, 200);
                 $image_resize->save(public_path('/images/items/' . $filename));
 
                 $ItemImage = $path . '/' . $currentImage;
                 if (file_exists($ItemImage)) {
                     if ($currentImage != 'no-image.png') {
                         @unlink($ItemImage);
                     }
                 }
             } else if (!$currentImage && $request->image !='null'){
                 $image = $request->file('image');
                 $path = public_path() . '/images/items';
                 $filename = rand(11111111, 99999999) . $image->getClientOriginalName();
 
                 $image_resize = Image::make($image->getRealPath());
                 $image_resize->resize(200, 200);
                 $image_resize->save(public_path('/images/items/' . $filename));
             }
 
             else {
                 $filename = $currentImage?$currentImage:'no-image.png';
             }
 
             Item::whereId($id)->update([
                 'ar_name' => $request['ar_name'],
                 'room_id' => $request['room_id'],
                 'category_id' => $request['category_id'],
                 'status' => $request['status'],
                 'purchase_date' => $request['purchase_date'],
                 
                 'image' => $filename,
             ]);
 
         }, 10);
 
         return response()->json(['success' => true]);
     }

    //------------ Delete Item -----------\

    public function destroy(Request $request, $id)
    {
        // $this->authorizeForUser($request->user('api'), 'delete', Item::class);

        Item::whereId($id)->update([
            'deleted_at' => Carbon::now(),
        ]);
        return response()->json(['success' => true]);
    }

    //-------------- Delete by selection  ---------------\

    public function delete_by_selection(Request $request)
    {

        // $this->authorizeForUser($request->user('api'), 'delete', Item::class);

        $selectedIds = $request->selectedIds;
        foreach ($selectedIds as $item_id) {
            Item::whereId($item_id)->update([
                'deleted_at' => Carbon::now(),
            ]);
        }
        return response()->json(['success' => true]);

    }

}

